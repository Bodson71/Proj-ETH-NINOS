class VisitorController < ApplicationController
  
  def index
    
  end
end
